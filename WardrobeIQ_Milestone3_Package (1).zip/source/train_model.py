"""
Train a WardrobeIQ clothing-category classifier with MobileNetV2 transfer learning.
Expected folders:
data/train/<class_name>/*.jpg
data/val/<class_name>/*.jpg
data/test/<class_name>/*.jpg

Run: python train_model.py
Optional offline training: set IMAGENET_WEIGHTS=0 in the environment.
"""
import os, json
from pathlib import Path
import tensorflow as tf
from tensorflow.keras import layers, models

ROOT = Path("data")
IMG_SIZE = (224,224)
BATCH = 32
EPOCHS_HEAD = 8
EPOCHS_FINE = 5
weights = "imagenet" if os.getenv("IMAGENET_WEIGHTS","1") == "1" else None

def load_split(name, class_names=None, shuffle=True):
    path = ROOT/name
    ds = tf.keras.utils.image_dataset_from_directory(
        path, image_size=IMG_SIZE, batch_size=BATCH, label_mode="int",
        class_names=class_names, shuffle=shuffle, seed=42
    )
    return ds

def main():
    train = load_split("train")
    names = train.class_names
    val = load_split("val", class_names=names, shuffle=False)
    test = load_split("test", class_names=names, shuffle=False)
    Path("models").mkdir(exist_ok=True)
    (Path("models")/"class_names.json").write_text(json.dumps(names, indent=2))
    autotune = tf.data.AUTOTUNE
    train = train.prefetch(autotune); val = val.prefetch(autotune); test = test.prefetch(autotune)

    aug = tf.keras.Sequential([
        layers.RandomFlip("horizontal"),
        layers.RandomRotation(0.08),
        layers.RandomZoom(0.10),
    ], name="augmentation")
    base = tf.keras.applications.MobileNetV2(
        input_shape=(224,224,3), include_top=False, weights=weights
    )
    base.trainable = False
    inputs = layers.Input(shape=(224,224,3))
    x = aug(inputs)
    x = tf.keras.applications.mobilenet_v2.preprocess_input(x)
    x = base(x, training=False)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.25)(x)
    outputs = layers.Dense(len(names), activation="softmax")(x)
    model = models.Model(inputs, outputs)
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3),
                  loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    model.fit(train, validation_data=val, epochs=EPOCHS_HEAD)

    # Fine-tune only the final portion of the feature extractor.
    base.trainable = True
    for layer in base.layers[:-30]:
        layer.trainable = False
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-5),
                  loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    model.fit(train, validation_data=val, epochs=EPOCHS_FINE)

    loss, acc = model.evaluate(test, verbose=1)
    print(f"TEST_LOSS={loss:.4f}")
    print(f"TEST_ACCURACY={acc:.4f}")
    # Detailed class-wise report and confusion matrix
    import numpy as np
    from sklearn.metrics import classification_report, confusion_matrix
    y_true = np.concatenate([y.numpy() for _,y in test])
    probs = model.predict(test, verbose=0)
    y_pred = probs.argmax(axis=1)
    print(classification_report(y_true, y_pred, target_names=names, zero_division=0))
    print("CONFUSION_MATRIX")
    print(confusion_matrix(y_true, y_pred))
    model.save("models/wardrobeiq_mobilenetv2.keras")
    print("Saved model and class labels in models/")

if __name__ == "__main__":
    main()
