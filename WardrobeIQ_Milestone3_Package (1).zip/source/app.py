import json, math, itertools
from pathlib import Path
from collections import Counter
import streamlit as st
import pandas as pd
from PIL import Image, ImageStat
import numpy as np

st.set_page_config(page_title="WardrobeIQ", page_icon="👗", layout="wide")
MODEL_PATH = Path("models/wardrobeiq_mobilenetv2.keras")
LABEL_PATH = Path("models/class_names.json")

CATEGORIES = ["top", "shirt", "t-shirt", "jeans", "trousers", "skirt", "dress", "jacket", "shoes", "accessory"]
OCCASIONS = ["Casual", "College", "Formal", "Party", "Festive", "Date"]
STYLES = ["Minimal", "Streetwear", "Classic", "Smart casual", "Ethnic", "Trendy"]

def rgb_to_hex(rgb):
    return '#%02x%02x%02x' % tuple(int(max(0,min(255,x))) for x in rgb)

def extract_color(img):
    im = img.convert("RGB").resize((50,50))
    arr = np.asarray(im).reshape(-1,3)
    # Robust approximate dominant color: median RGB, avoids dependency on clustering packages.
    rgb = np.median(arr, axis=0)
    return rgb_to_hex(rgb)

def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i+2],16) for i in (0,2,4))

def color_harmony(a,b):
    # Approximate color distance; neutral colors receive a compatibility bonus.
    x, y = np.array(hex_rgb(a)), np.array(hex_rgb(b))
    dist = float(np.linalg.norm(x-y) / (255*np.sqrt(3)))
    sat_x, sat_y = [max(hex_rgb(c))-min(hex_rgb(c)) for c in (a,b)]
    neutral_bonus = 0.18 if sat_x < 35 or sat_y < 35 else 0
    return max(0.0, min(1.0, 1.0-dist+neutral_bonus))

def predict_category(img):
    if not (MODEL_PATH.exists() and LABEL_PATH.exists()):
        return None, None
    try:
        import tensorflow as tf
        model = tf.keras.models.load_model(MODEL_PATH)
        labels = json.loads(LABEL_PATH.read_text())
        im = img.convert("RGB").resize((224,224))
        x = np.asarray(im, dtype=np.float32)
        x = tf.keras.applications.mobilenet_v2.preprocess_input(x)
        probs = model.predict(np.expand_dims(x,0), verbose=0)[0]
        idx = int(np.argmax(probs))
        return labels[idx], float(probs[idx])
    except Exception as e:
        st.warning(f"Model could not be loaded; use manual category selection. Details: {e}")
        return None, None

if "wardrobe" not in st.session_state: st.session_state.wardrobe = []
if "history" not in st.session_state: st.session_state.history = []
if "feedback" not in st.session_state: st.session_state.feedback = {}

st.title("WardrobeIQ")
st.caption("AI-powered personalized outfit recommendations from the clothes you already own.")
tab1, tab2, tab3, tab4 = st.tabs(["My Wardrobe", "Get Outfit Ideas", "Style DNA & History", "About"])

with tab1:
    st.subheader("Build your digital wardrobe")
    st.write("Upload a clothing photo. If a trained classifier is available, WardrobeIQ predicts its category; otherwise choose the category manually.")
    uploaded = st.file_uploader("Upload a clothing item", type=["jpg","jpeg","png"], key="garment")
    if uploaded:
        image = Image.open(uploaded).convert("RGB")
        st.image(image, width=230)
        pred, conf = predict_category(image)
        default_cat = pred if pred in CATEGORIES else "top"
        if pred:
            st.success(f"Model prediction: {pred} ({conf:.1%} confidence)")
        category = st.selectbox("Category", CATEGORIES, index=CATEGORIES.index(default_cat))
        color = extract_color(image)
        st.markdown(f"Approximate dominant colour: **{color}**")
        col1, col2 = st.columns(2)
        with col1: style = st.selectbox("Style", STYLES)
        with col2: occasion = st.selectbox("Suitable occasion", OCCASIONS)
        item_name = st.text_input("Item name (optional)", value=uploaded.name.rsplit(".",1)[0])
        if st.button("Add to my wardrobe"):
            st.session_state.wardrobe.append({
                "id": len(st.session_state.wardrobe)+1, "name": item_name or category,
                "category": category, "color": color, "style": style, "occasion": occasion,
                "image": image.copy()
            })
            st.success("Item added to your wardrobe.")
    if st.session_state.wardrobe:
        st.subheader(f"Saved items ({len(st.session_state.wardrobe)})")
        cols = st.columns(4)
        for i, item in enumerate(st.session_state.wardrobe):
            with cols[i%4]:
                st.image(item["image"], use_container_width=True)
                st.write(f"**{item['name']}**")
                st.caption(f"{item['category']} · {item['style']} · {item['color']}")
                if st.button("Remove", key=f"remove_{item['id']}"):
                    st.session_state.wardrobe = [x for x in st.session_state.wardrobe if x["id"] != item["id"]]
                    st.rerun()
    else:
        st.info("Your wardrobe is empty. Add a few tops, bottoms and shoes to generate combinations.")

with tab2:
    st.subheader("Personalized outfit generator")
    if len(st.session_state.wardrobe) < 2:
        st.info("Add at least two items. For a complete outfit, add tops, bottoms and shoes.")
    else:
        pref_style = st.selectbox("Preferred style", ["Any"]+STYLES, key="pref_style")
        pref_occ = st.selectbox("Occasion", ["Any"]+OCCASIONS, key="pref_occ")
        avoid_repeat = st.checkbox("Reduce recently shown combinations", value=True)
        items = st.session_state.wardrobe
        tops = [x for x in items if x["category"] in ["top","shirt","t-shirt","dress"]]
        bottoms = [x for x in items if x["category"] in ["jeans","trousers","skirt"]]
        shoes = [x for x in items if x["category"] == "shoes"]
        combos = []
        if tops and bottoms:
            for t,b in itertools.product(tops,bottoms):
                for s in (shoes or [None]):
                    parts = [t,b] + ([s] if s else [])
                    if pref_style != "Any" and not any(p["style"] == pref_style for p in parts): continue
                    if pref_occ != "Any" and not any(p["occasion"] == pref_occ for p in parts): continue
                    color_score = color_harmony(t["color"], b["color"])
                    style_score = sum(p["style"] == t["style"] for p in parts)/len(parts)
                    occasion_score = 1.0 if pref_occ == "Any" else sum(p["occasion"] == pref_occ for p in parts)/len(parts)
                    key = "-".join(str(p["id"]) for p in parts)
                    repeat_penalty = 0.25 if key in st.session_state.history[-5:] else 0
                    score = 0.55*color_score + 0.25*style_score + 0.20*occasion_score - (repeat_penalty if avoid_repeat else 0)
                    combos.append((score,key,parts))
        if not combos:
            st.warning("No complete combinations match these filters. Add more wardrobe categories or select Any.")
        else:
            combos.sort(key=lambda z:z[0], reverse=True)
            for rank,(score,key,parts) in enumerate(combos[:5],1):
                with st.container(border=True):
                    st.write(f"**Look {rank}**  ·  Compatibility score: {score:.2f}/1.00")
                    cols = st.columns(len(parts))
                    for c,p in zip(cols,parts):
                        with c:
                            st.image(p["image"], use_container_width=True)
                            st.caption(f"{p['name']} ({p['category']})")
                    c1,c2,c3 = st.columns([1,1,3])
                    with c1:
                        if st.button("Like", key=f"like_{key}"):
                            st.session_state.feedback[key] = "liked"
                            st.success("Preference saved for this session.")
                    with c2:
                        if st.button("Wear this", key=f"wear_{key}"):
                            st.session_state.history.append(key)
                            st.success("Added to outfit history.")
                    with c3:
                        if st.button("Skip", key=f"skip_{key}"):
                            st.session_state.feedback[key] = "skipped"
                            st.info("Skip feedback saved for this session.")
            st.caption("Scores are heuristic ranking scores, not probabilities or learned compatibility predictions.")

with tab3:
    st.subheader("Style DNA")
    if st.session_state.wardrobe:
        styles = Counter(x["style"] for x in st.session_state.wardrobe)
        st.write("Your current wardrobe style mix:")
        st.bar_chart(pd.DataFrame({"items":styles}).sort_values("items",ascending=False))
        cats = Counter(x["category"] for x in st.session_state.wardrobe)
        st.write("Category balance:", dict(cats))
        st.write(f"Saved outfit history entries: {len(st.session_state.history)}")
        st.write(f"Feedback entries this session: {len(st.session_state.feedback)}")
    else:
        st.info("Add wardrobe items to build your Style DNA.")
    if st.button("Clear outfit history"):
        st.session_state.history = []
        st.success("History cleared.")

with tab4:
    st.subheader("How WardrobeIQ works")
    st.markdown("""
    1. **Wardrobe input:** users upload images of clothes they already own.
    2. **Image understanding:** a MobileNetV2 transfer-learning classifier can predict garment categories when a trained model is installed.
    3. **Feature representation:** each item stores category, approximate dominant colour, style and occasion.
    4. **Recommendation:** a content-based scoring function ranks compatible top-bottom-shoe combinations.
    5. **Personalization:** likes, skips and worn-look history are recorded during the app session to support preference-aware ranking and repetition control.

    **Current prototype limitation:** session data is temporary and is cleared when the app session resets. Persistent database storage, user accounts, richer colour extraction and learned feedback ranking are future engineering improvements.
    """)
