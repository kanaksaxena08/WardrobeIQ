# WardrobeIQ — Final Viva Preparation

## Project basics
**Q1. What is WardrobeIQ?**  
WardrobeIQ is an AI/ML-based personalized outfit recommendation system. It works with clothes a user already owns and suggests combinations instead of primarily recommending products to buy.

**Q2. What problem does it solve?**  
People may own many clothes but still struggle to decide what goes together. Generic fashion suggestions may not reflect their actual wardrobe. WardrobeIQ creates a digital wardrobe and ranks combinations from those items.

**Q3. What are the main modules?**  
Image upload, clothing-category classification, feature extraction, outfit compatibility scoring, personalized ranking, and outfit history/feedback.

## Machine learning
**Q4. Why is computer vision used?**  
The input is clothing images. Computer vision helps extract visual information and identify clothing categories.

**Q5. What is a CNN?**  
A Convolutional Neural Network is a deep-learning model designed to process grid-like data such as images. Convolution filters learn patterns such as edges, textures and shapes.

**Q6. What is transfer learning?**  
It reuses knowledge from a model trained on a large dataset and adapts it to a new task. It can reduce training time and data requirements compared with training a deep network from scratch.

**Q7. Why MobileNetV2?**  
It is a comparatively lightweight CNN architecture, making it practical for a student prototype with limited compute. Its pretrained feature extractor can be adapted to clothing categories. The final suitability must be supported by actual test results.

**Q8. What does the classifier output?**  
A probability distribution across the clothing classes configured in the training folders. The class with the highest predicted score is selected as the predicted category. This score is not a guarantee of correctness.

**Q9. Why split data into train, validation and test?**  
Training data fits model parameters, validation data helps monitor/tune training, and test data gives a final estimate on unseen examples. The test set should not be used to tune the model.

**Q10. What is overfitting?**  
When a model performs well on training data but poorly on unseen data because it has memorized training examples rather than learning patterns that generalize.

**Q11. Which metrics do you use?**  
Accuracy gives the overall fraction correct. Precision measures how many predictions for a class were correct. Recall measures how many actual examples of a class were found. F1-score is the harmonic mean of precision and recall. A confusion matrix shows class-wise correct and incorrect predictions.

## Recommendation system
**Q12. Is outfit recommendation the same as image classification?**  
No. Classification identifies what an item is. Recommendation ranks combinations of items that may work well together.

**Q13. How does your recommendation score work?**  
The prototype uses a weighted content-based score combining color compatibility, style match and occasion match, then subtracts a penalty for recently shown combinations. The weights are heuristic and should be tuned using user feedback or a labelled compatibility dataset.

**Q14. Why content-based recommendation?**  
At the beginning, there may be little or no user interaction history. Content-based recommendation can use item attributes immediately and works with the user's own wardrobe.

**Q15. How does personalization happen?**  
The prototype records likes, skips and worn combinations during the session. These signals can be used to adjust future rankings. In this version, feedback tracking is a foundation for personalization rather than a fully trained preference-learning model.

**Q16. How do you reduce repeated outfits?**  
The system stores recently worn or shown combinations and applies a repetition penalty to those combinations.

## Prototype and limitations
**Q17. What happens if the classifier is not trained?**  
The prototype supports manual category selection. Automatic classification is enabled after the training script produces the model and class-label file.

**Q18. What are the limitations?**  
The classifier depends on dataset quality and class coverage. The color feature is approximate. Compatibility scoring is heuristic. Session data is temporary, and the current prototype does not provide persistent user accounts or a production database.

**Q19. What would you improve next?**  
Use a larger and more diverse labelled dataset, improve color/pattern/style extraction, learn compatibility from outfit datasets, persist wardrobe/history in a database, and add context such as weather and body-type-aware styling after validation.

**Q20. What is the innovation?**  
The focus is on recommending combinations from a user's existing wardrobe, with preference feedback and repetition control, rather than only recommending new products.

## Be ready to show
- Actual dataset source and license
- Number of images in each class and split
- Training/validation curves
- Test accuracy, precision, recall and F1
- Confusion matrix
- Working app screenshots
- One example recommendation and how its score was calculated
