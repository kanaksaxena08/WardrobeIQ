# WardrobeIQ — Milestone 3 Starter Package

AI-powered personalized outfit recommendation using the user's existing wardrobe.

## What's included
- `app.py`: Streamlit prototype with wardrobe upload, optional model-based garment classification, color/style/occasion features, outfit ranking, likes/skips and outfit history.
- `train_model.py`: MobileNetV2 transfer-learning training and test evaluation script.
- `requirements.txt`: Python dependencies.
- `WardrobeIQ_Milestone3_Report.docx`: report draft.
- `WardrobeIQ_Milestone3_Presentation.pptx`: final presentation draft.
- `Viva_Questions.md`: likely viva questions and beginner-friendly answers.

## 1. Install and run the prototype
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```
The app can run without a trained model. In that case, choose each garment category manually. This is a functioning recommendation prototype, but it does not demonstrate automatic AI classification until a trained model is supplied.

## 2. Prepare image data for training
Create this structure, with one folder per clothing class:
```text
data/
  train/
    top/
    jeans/
    trousers/
    shoes/
    jacket/
  val/
    top/
    jeans/
    trousers/
    shoes/
    jacket/
  test/
    top/
    jeans/
    trousers/
    shoes/
    jacket/
```
Use the same class folder names in all three splits. Put only images of the matching category in each folder. Avoid placing duplicate or near-identical images across train/validation/test. Include enough examples per class and check for class imbalance. Keep a record of the actual source, license, image count and split counts.

## 3. Train and evaluate
```bash
python train_model.py
```
The script trains a MobileNetV2 transfer-learning classifier, evaluates it on the held-out test split, prints accuracy, precision, recall, F1-score and a confusion matrix, then saves:
- `models/wardrobeiq_mobilenetv2.keras`
- `models/class_names.json`

For an offline environment without pretrained weights:
- Windows PowerShell: `$env:IMAGENET_WEIGHTS="0"`
- macOS/Linux: `IMAGENET_WEIGHTS=0 python train_model.py`

The app detects the saved model and uses it to predict garment categories.

## 4. Important academic honesty / finalization checklist
- Do not write an accuracy value until `train_model.py` has been run on your actual held-out test set.
- Insert the actual dataset source, license, class names, image counts and split counts in the report.
- Add screenshots of your running app and actual model output.
- Record any errors or limitations honestly.
- The outfit compatibility score in this prototype is a transparent heuristic ranking score, not a trained probability model.
- The prototype currently stores data in Streamlit session state; persistent database/user accounts are proposed improvements.

## 5. Suggested demo sequence
1. Open My Wardrobe and upload a top, jeans/trousers and shoes.
2. Show the predicted category if the trained model is installed; otherwise show manual category entry.
3. Open Get Outfit Ideas and select an occasion/style.
4. Explain how color compatibility, style match and occasion match contribute to the ranking.
5. Click Like, Skip or Wear this.
6. Open Style DNA & History to show the current session's wardrobe mix and outfit history.
